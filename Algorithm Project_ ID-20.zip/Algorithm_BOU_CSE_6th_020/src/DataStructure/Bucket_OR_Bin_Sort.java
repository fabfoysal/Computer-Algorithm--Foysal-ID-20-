package DataStructure;

import java.util.*;
import java.util.Collections;

public class Bucket_OR_Bin_Sort {

//    private static void bucketSorting(Float[] arr, int i) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    class BucketSort {

//        void bucketSorting(Float a[], int size) {
    public static void main(String[] args) {
        Float a[] = {0.56f, 0.78f, 0.72f, 0.87f, 0.15f, 0.1f, 0.11f};
        int size = 10;
            if (size <= 0) {
                return;
            }

            Vector<Float> bucket[] = new Vector[size];
            for (int j = 0; j < size; j++) {
                bucket[j] = new Vector<>();
            }

            for (int j = 0; j < size; j++) {
                float i = a[j] * size;

                int index = (int) i;

                bucket[index].add(a[j]);
            }

            for (int j = 0; j < size; j++) {
                Collections.sort(bucket[j]);
            }

            int idx = 0;

            for (int j = 0; j < size; j++) {

                for (int i = 0; i < bucket[j].size(); i++) {

                    a[idx] = bucket[j].get(i);
                    idx = idx + 1;
                }
            }
        }
//    }
    
}